package ventas;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Ventas {

    // Clase Cliente
    static class Cliente {
        private String dni;
        private String nombre;

        public Cliente(String dni, String nombre) {
            this.dni = dni;
            this.nombre = nombre;
        }

        public String getDni() {
            return dni;
        }

        public void setDni(String dni) {
            this.dni = dni;
        }

        public String getNombre() {
            return nombre;
        }

        public void setNombre(String nombre) {
            this.nombre = nombre;
        }

        @Override
        public String toString() {
            return "DNI: " + dni + ", Nombre: " + nombre;
        }
    }

    // Clase Articulo
    static class Articulo {
        private String codigo;
        private String descripcion;
        private double precio;

        public Articulo(String codigo, String descripcion, double precio) {
            this.codigo = codigo;
            this.descripcion = descripcion;
            this.precio = precio;
        }

        public String getCodigo() {
            return codigo;
        }

        public void setCodigo(String codigo) {
            this.codigo = codigo;
        }

        public String getDescripcion() {
            return descripcion;
        }

        public void setDescripcion(String descripcion) {
            this.descripcion = descripcion;
        }

        public double getPrecio() {
            return precio;
        }

        public void setPrecio(double precio) {
            this.precio = precio;
        }

        @Override
        public String toString() {
            return "Código: " + codigo + ", Descripción: " + descripcion + ", Precio: " + precio;
        }
    }

    // Clase DetallePedido
    static class DetallePedido {
        private int cantidad;
        private Articulo articulo;

        public DetallePedido(int cantidad, Articulo articulo) {
            this.cantidad = cantidad;
            this.articulo = articulo;
        }

        public int getCantidad() {
            return cantidad;
        }

        public void setCantidad(int cantidad) {
            this.cantidad = cantidad;
        }

        public Articulo getArticulo() {
            return articulo;
        }

        public void setArticulo(Articulo articulo) {
            this.articulo = articulo;
        }

        @Override
        public String toString() {
            return "Artículo: " + articulo.getDescripcion() +
                    ", Cantidad: " + cantidad +
                    ", Subtotal: " + (cantidad * articulo.getPrecio());
        }
    }

    // Clase OrdenPedido
    static class OrdenPedido {
        private int numero;
        private Date fecha;
        private Cliente cliente;
        private List<DetallePedido> detalles;

        public OrdenPedido(int numero, Date fecha, Cliente cliente) {
            this.numero = numero;
            this.fecha = fecha;
            this.cliente = cliente;
            this.detalles = new ArrayList<>();
        }

        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }

        public Date getFecha() {
            return fecha;
        }

        public void setFecha(Date fecha) {
            this.fecha = fecha;
        }

        public Cliente getCliente() {
            return cliente;
        }

        public void setCliente(Cliente cliente) {
            this.cliente = cliente;
        }

        public void agregarDetalle(DetallePedido detalle) {
            detalles.add(detalle);
        }

        public List<DetallePedido> getDetalles() {
            return detalles;
        }

        public double obtenerTotal() {
            double total = 0;
            for (DetallePedido detalle : detalles) {
                total += detalle.getCantidad() * detalle.getArticulo().getPrecio();
            }
            return total;
        }

        @Override
        public String toString() {
            return "Número de Pedido: " + numero + 
                   ", Fecha: " + fecha + 
                   ", Cliente: [" + cliente + "]";
        }
    }

    // Método principal
    public static void main(String[] args) {
        // Listas para almacenar datos
        try (Scanner scanner = new Scanner(System.in)) {
            // Listas para almacenar datos
            List<Cliente> clientes = new ArrayList<>();
            List<Articulo> articulos = new ArrayList<>();
            List<OrdenPedido> pedidos = new ArrayList<>();
            
            // Variables auxiliares
            int numeroPedido = 1;
            
            boolean salir = false;
            
            while (!salir) {
                System.out.println("\n--- Menú Principal ---");
                System.out.println("1. Agregar/Modificar Cliente");
                System.out.println("2. Agregar/Modificar Artículo");
                System.out.println("3. Crear Pedido");
                System.out.println("4. Mostrar Pedidos");
                System.out.println("5. Salir");
                System.out.print("Seleccione una opción: ");
                int opcion = scanner.nextInt();
                
                switch (opcion) {
                    case 1 -> {
                        // Cliente
                        System.out.println("\n1) Agregar Cliente");
                        System.out.println("2) Obtener y Modificar Cliente");
                        System.out.print("Seleccione una sub-opción: ");
                        int subOpcionCliente = scanner.nextInt();
                        
                        if (subOpcionCliente == 1) {
                            System.out.print("Ingrese el DNI del cliente: ");
                            String dni = scanner.next();
                            System.out.print("Ingrese el nombre del cliente: ");
                            String nombre = scanner.next();
                            clientes.add(new Cliente(dni, nombre));
                            System.out.println("Cliente agregado exitosamente.");
                        } else if (subOpcionCliente == 2) {
                            if (clientes.isEmpty()) {
                                System.out.println("No hay clientes registrados.");
                                break;
                            }
                            System.out.println("Seleccione un cliente para modificar:");
                            for (int i = 0; i < clientes.size(); i++) {
                                System.out.println((i + 1) + ". " + clientes.get(i));
                            }
                            System.out.print("Seleccione un cliente: ");
                            int clienteIndex = scanner.nextInt() - 1;
                            
                            Cliente clienteSeleccionado = clientes.get(clienteIndex);
                            
                            System.out.println("\n1) Modificar Nombre");
                            System.out.println("2) Modificar DNI");
                            System.out.print("Seleccione una sub-opción: ");
                            int modificarCliente = scanner.nextInt();
                            
                            switch (modificarCliente) {
                                case 1 -> {
                                    System.out.print("Ingrese el nuevo nombre: ");
                                    clienteSeleccionado.setNombre(scanner.next());
                                    System.out.println("Nombre actualizado.");
                                }
                                case 2 -> {
                                    System.out.print("Ingrese el nuevo DNI: ");
                                    clienteSeleccionado.setDni(scanner.next());
                                    System.out.println("DNI actualizado.");
                                }
                                default -> System.out.println("Opción no válida.");
                            }
                        }
                    }
                        
                    case 2 -> {
                        // Artículo
                        System.out.println("\n1) Agregar Artículo");
                        System.out.println("2) Obtener y Modificar Artículo");
                        System.out.print("Seleccione una sub-opción: ");
                        int subOpcionArticulo = scanner.nextInt();
                        
                        if (subOpcionArticulo == 1) {
                            System.out.print("Ingrese el código del artículo: ");
                            String codigo = scanner.next();
                            System.out.print("Ingrese la descripción del artículo: ");
                            String descripcion = scanner.next();
                            System.out.print("Ingrese el precio del artículo: ");
                            double precio = scanner.nextDouble();
                            articulos.add(new Articulo(codigo, descripcion, precio));
                            System.out.println("Artículo agregado exitosamente.");
                        } else if (subOpcionArticulo == 2) {
                            if (articulos.isEmpty()) {
                                System.out.println("No hay artículos registrados.");
                                break;
                            }
                            System.out.println("Seleccione un artículo para modificar:");
                            for (int i = 0; i < articulos.size(); i++) {
                                System.out.println((i + 1) + ". " + articulos.get(i));
                            }
                            System.out.print("Seleccione un artículo: ");
                            int articuloIndex = scanner.nextInt() - 1;
                            
                            Articulo articuloSeleccionado = articulos.get(articuloIndex);
                            
                            System.out.println("\n1) Modificar Código");
                            System.out.println("2) Modificar Descripción");
                            System.out.println("3) Modificar Precio");
                            System.out.print("Seleccione una sub-opción: ");
                            int modificarArticulo = scanner.nextInt();
                            
                            switch (modificarArticulo) {
                                case 1 -> {
                                    System.out.print("Ingrese el nuevo código: ");
                                    articuloSeleccionado.setCodigo(scanner.next());
                                    System.out.println("Código actualizado.");
                                }
                                case 2 -> {
                                    System.out.print("Ingrese la nueva descripción: ");
                                    articuloSeleccionado.setDescripcion(scanner.next());
                                    System.out.println("Descripción actualizada.");
                                }
                                case 3 -> {
                                    System.out.print("Ingrese el nuevo precio: ");
                                    articuloSeleccionado.setPrecio(scanner.nextDouble());
                                    System.out.println("Precio actualizado.");
                                }
                                default -> System.out.println("Opción no válida.");
                            }
                        }
                    }
                        
                    case 3 -> {
                        // Crear Pedido
                        if (clientes.isEmpty() || articulos.isEmpty()) {
                            System.out.println("Debe haber al menos un cliente y un artículo para crear un pedido.");
                            break;
                        }

                        System.out.println("Seleccione un cliente:");
                        for (int i = 0; i < clientes.size(); i++) {
                            System.out.println((i + 1) + ". " + clientes.get(i));
                        }
                        System.out.print("Seleccione una opción: ");
                        int clienteIndex = scanner.nextInt() - 1;
                        Cliente clienteSeleccionado = clientes.get(clienteIndex);
                        
                        OrdenPedido pedido = new OrdenPedido(numeroPedido++, new Date(), clienteSeleccionado);
                        
                        boolean agregarDetalles = true;
                        while (agregarDetalles) {
                            System.out.println("Seleccione un artículo:");
                            for (int i = 0; i < articulos.size(); i++) {
                                System.out.println((i + 1) + ". " + articulos.get(i));
                            }
                            System.out.print("Seleccione una opción: ");
                            int articuloIndex = scanner.nextInt() - 1;
                            Articulo articuloSeleccionado = articulos.get(articuloIndex);
                            
                            System.out.print("Ingrese la cantidad: ");
                            int cantidad = scanner.nextInt();
                            
                            DetallePedido detalle = new DetallePedido(cantidad, articuloSeleccionado);
                            pedido.agregarDetalle(detalle);
                            
                            System.out.print("¿Desea agregar otro detalle? (1: Sí, 0: No): ");
                            agregarDetalles = scanner.nextInt() == 1;
                        }
                        
                        pedidos.add(pedido);
                        System.out.println("Pedido creado exitosamente.");
                    }
                        
                    case 4 -> {
                        // Mostrar Pedidos
                        if (pedidos.isEmpty()) {
                            System.out.println("No hay pedidos creados.");
                        } else {
                            for (OrdenPedido p : pedidos) {
                                System.out.println(p);
                                for (DetallePedido detalle : p.getDetalles()) {
                                    System.out.println("  " + detalle);
                                }
                                System.out.println("Total: " + p.obtenerTotal());
                            }
                        }
                    }
                        
                    case 5 -> {
                        // Salir
                        salir = true;
                        System.out.println("Gracias por usar el sistema.");
                    }
                        
                    default -> System.out.println("Opción no válida.");
                }
            }
        }
    }
}

